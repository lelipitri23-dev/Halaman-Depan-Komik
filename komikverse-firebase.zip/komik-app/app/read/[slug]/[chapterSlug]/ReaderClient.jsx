'use client';
import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';

export default function ReaderClient() {
  const params = useParams();
  const router = useRouter();
  const { slug, chapterSlug } = params;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [uiVisible, setUiVisible] = useState(true);
  const [progress, setProgress] = useState(0);
  const lastScrollY = useRef(0);
  const hideTimer = useRef(null);

  useEffect(() => {
    async function fetchChapter() {
      setLoading(true);
      setError(null);
      try {
        const proxyBase = `${window.location.origin}/api/proxy`;
        const res = await fetch(`${proxyBase}/read/${slug}/${chapterSlug}`);
        const json = await res.json();
        if (!json.success) throw new Error(json.message);
        setData(json.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
    fetchChapter();
  }, [slug, chapterSlug]);

  // Scroll progress & UI auto-hide
  const handleScroll = useCallback(() => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    setProgress(docHeight > 0 ? Math.round((scrollTop / docHeight) * 100) : 0);

    if (scrollTop < lastScrollY.current) {
      setUiVisible(true);
    } else {
      if (hideTimer.current) clearTimeout(hideTimer.current);
      hideTimer.current = setTimeout(() => setUiVisible(false), 2000);
    }
    lastScrollY.current = scrollTop;
  }, []);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  const toggleUI = () => setUiVisible((v) => !v);

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center gap-4">
        <div className="w-10 h-10 border-2 border-accent-red/30 border-t-accent-red rounded-full animate-spin" />
        <p className="text-text-muted text-sm">Memuat chapter...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="fixed inset-0 bg-bg-primary flex flex-col items-center justify-center gap-4 p-4 text-center">
        <span className="text-5xl">😵</span>
        <p className="font-display text-xl text-text-secondary tracking-wider">CHAPTER TIDAK DITEMUKAN</p>
        <p className="text-text-muted text-sm">{error || 'Terjadi kesalahan'}</p>
        <button onClick={() => router.back()} className="px-6 py-2 bg-accent-red rounded-xl text-white font-bold text-sm">
          Kembali
        </button>
      </div>
    );
  }

  const { chapter, manga, navigation } = data;

  return (
    <div className="bg-black min-h-screen" onClick={toggleUI}>
      {/* Progress bar */}
      <div className="fixed top-0 left-0 right-0 z-50 h-0.5 bg-bg-elevated">
        <div
          className="h-full bg-accent-red transition-all duration-200"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Top UI */}
      <div
        className={`fixed top-0 left-0 right-0 z-40 bg-bg-primary/95 backdrop-blur-md border-b border-border transition-transform duration-300 ${
          uiVisible ? 'translate-y-0' : '-translate-y-full'
        }`}
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="flex items-center gap-3 px-3 h-14 max-w-2xl mx-auto">
          <Link
            href={`/manga/${manga.slug}`}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-bg-elevated border border-border text-text-secondary hover:border-accent-red hover:text-accent-red transition-colors flex-shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-5 h-5">
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </Link>
          <div className="flex-1 min-w-0">
            <p className="text-text-primary font-bold text-sm truncate leading-tight">{manga.title}</p>
            <p className="text-text-muted text-[11px] truncate">{chapter.title}</p>
          </div>
          <span className="text-text-muted text-xs font-semibold flex-shrink-0">{progress}%</span>
        </div>
      </div>

      {/* Images */}
      <div className="max-w-2xl mx-auto" style={{ paddingTop: '56px', paddingBottom: '80px' }}>
        {chapter.images?.length > 0 ? (
          chapter.images.map((img, idx) => (
            <div key={idx} className="relative w-full">
              <img
                src={img}
                alt={`${manga.title} ${chapter.title} - Halaman ${idx + 1}`}
                className="reader-image"
                loading={idx < 3 ? 'eager' : 'lazy'}
                draggable={false}
                onClick={(e) => e.stopPropagation()}
              />
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center min-h-screen gap-4 text-center p-4">
            <span className="text-5xl">📭</span>
            <p className="font-display text-xl text-text-secondary">TIDAK ADA GAMBAR</p>
          </div>
        )}
      </div>

      {/* Bottom Navigation UI */}
      <div
        className={`fixed bottom-0 left-0 right-0 z-40 bg-bg-primary/95 backdrop-blur-md border-t border-border transition-transform duration-300 ${
          uiVisible ? 'translate-y-0' : 'translate-y-full'
        }`}
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 px-3 h-16 max-w-2xl mx-auto">
          {navigation?.prev ? (
            <Link
              href={`/read/${manga.slug}/${navigation.prev}`}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-bg-elevated border border-border text-text-secondary hover:border-accent-red hover:text-accent-red transition-colors text-sm font-bold flex-shrink-0"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-4 h-4">
                <polyline points="15 18 9 12 15 6" />
              </svg>
              Prev
            </Link>
          ) : (
            <div className="px-4 py-2.5 text-sm font-bold text-text-muted opacity-30 flex-shrink-0">Prev</div>
          )}

          <div className="flex-1 text-center">
            <p className="text-text-muted text-xs">{chapter.title}</p>
          </div>

          {navigation?.next ? (
            <Link
              href={`/read/${manga.slug}/${navigation.next}`}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-accent-red text-white text-sm font-bold hover:bg-accent-redDark transition-colors flex-shrink-0"
            >
              Next
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-4 h-4">
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </Link>
          ) : (
            <Link
              href={`/manga/${manga.slug}`}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-bg-elevated border border-border text-text-secondary text-sm font-bold flex-shrink-0"
            >
              Selesai
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
